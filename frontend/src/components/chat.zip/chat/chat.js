import React,{useState} from 'react'
import Message from './message.js'
import NewMessage from './newMessage'
import './chat.scss'

export default function Chat(props) {

     const [messages,setMessages]=useState(props.messages);
     
    return (
        <div className='chat'>
             <NewMessage setState={setMessages} />
            <div className='poruke'>
                {messages.map(message=>{
                    return(<Message key={message.id} message={message} />)
                })}
            </div>
           
        </div>
    )
}
