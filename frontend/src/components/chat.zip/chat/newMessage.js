import React,{useState} from 'react'
import './newMessage.scss'

export default function NewMessage(props) {

    const [newMessage,setNewMessage]=useState("");
    const addMessage=()=>{

        const novaPoruka={
            tekst:newMessage,
            autor:'Pera peric',
            vreme:new Date().toLocaleString()
        }

       props.setState (prevState=>{
           novaPoruka.id=prevState.length;
           return [novaPoruka,...prevState]})
        
        setNewMessage("");

    }
    return (
          
       <div>
            <textarea className='polje'  rows='5' cols='80' placeholder="Napisite poruku"   value={newMessage} onChange={e=>setNewMessage(e.target.value)}></textarea>
            <div className='dugme' onClick={addMessage}>Posalji poruku</div>
            
        </div>
    )
}
