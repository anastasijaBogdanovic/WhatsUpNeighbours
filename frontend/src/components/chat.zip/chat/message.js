import React from 'react';
import './message.scss'

export default function Message(props) {
    return (
        <div className='kontejnerMessage'>
            
            <div className='poruka'>{props.message.tekst}</div>
            <div className='futer'><i>-{`${props.message.autor}, ${props.message.vreme}`}</i></div>
            
        </div>
    )
}

